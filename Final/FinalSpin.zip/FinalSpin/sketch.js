let wheel;
let angle = 0;

function preload() {
  wheel = loadImage("car_wheel.png");
}

function setup() {
  createCanvas(800, 600);
}

function draw() {
  background(128);

  let x = width / 3.0;
  let y = height / 3.0;

  rotate(angle);
  translate(x, y);

  image(wheel, -256, -256);

  angle += 0.02;
}
