// sketch.js

function setup() {
  createCanvas(600, 600);

}

function draw() {
  background(132, 162, 191);
  
  fill(0,0,0);
  arc(300, 600, 590, 1150, PI, 0);

  //head
  fill(255,255,255);
  ellipse(300, 310, 380, 500)

  //eyes
  //ellipse(x, y, w, [h])
  fill(0,0,0);

  ellipse(400, 250, 80, 40);
  ellipse(200, 250, 80, 40);

  ellipse(400, 300, 60, 12);
  ellipse(200, 300, 60, 12);

  //face markings
  //triangle(x1, y1, x2, y2, x3, y3)
  fill(115,90,150);

  triangle(370, 215, 430, 215, 400, 140);
  triangle(170, 215, 230, 215, 200, 140);

  triangle(375, 320, 425, 320, 400, 450);
  triangle(175, 320, 225, 320, 200, 450);
  
  
  //mouth
  fill(0,0,0);

  ellipse(300, 490, 120, 30);



  

}
